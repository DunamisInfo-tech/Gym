import datetime
import smtplib
from audioop import reverse
from datetime import date
from pyexpat.errors import messages

import chartit
from django.template import RequestContext
from django.shortcuts import render_to_response, redirect
import client
from chartit import DataPool, Chart
from dateutil.relativedelta import relativedelta
from django.contrib.auth import authenticate, login


from django.core.mail import send_mail
from django.db.models import Q

from django.shortcuts import render, redirect
from django.views import View
from twilio.rest import TwilioRestClient
from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
import xhtml2pdf.pisa as pisa
from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from .models import SalesReport
from chartit import DataPool, Chart

from app.render import Render
from .models import promotion, enquiry1, itemlist, mail1

from django.shortcuts import render, render_to_response

from django.http import HttpResponse, HttpResponseRedirect

from django.template import Context, Template, RequestContext
import datetime
import hashlib
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.template.context_processors import csrf

# created in step 4

account_sid = "ACa280b82ed3ceab6943fe9ebd1ee7a984"  # Found on Twilio Console Dashboard
auth_token = "664d1da11e15af4be2ee5fa513956d76"  # Found on Twilio Console Dashboard


# Create your views here.


def index(request):
    return render(request, 'index.html')


def ind(request):
    return render(request, 'in.html')


def index2(request):
    return render(request, 'getstarted.html')


def second(request):
    return render(request, 'second.html')


def basic(request):
    return render(request, 'basic.html')


def pre(request):
    return render(request, 'pre.html')


def business(request):
    return render(request, 'business.html')


def email(request):
    return render(request, 'email.html')


def click(request):
    return render(request, 'click.html')


def home(request):
    return render(request, 'home.html')


def pagelogin(request):
    return render(request, 'page-login.html')


def pageregister(request):
    return render(request, 'page-register.html')


def Promotion(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        start_date = request.POST['start_date']
        duration = request.POST['duration']
        end_date = request.POST['end_date']
        user = promotion.objects.create(name=name, email=email, phone=phone, start_date=start_date,
                                        duration=duration,
                                        end_date=end_date)
        user.save()
        return HttpResponse('Registered successfully')
    return render(request, 'promotion.html')


def index1(request):
    dests = promotion.objects.filter(end_date=date.today() + relativedelta(days=3))

    return render(request, 'proindex.html', {'dests': dests})


def enq(request):
    dests = promotion.objects.all()

    return render(request, 'enquiry.html', {'dests': dests})


def email1(request):
    dests = promotion.objects.all()
    for j in dests:
        date = j.end_date - datetime.timedelta(days=3)

        if date == date.today():
            print(j.email)
            print("sent")
            subject = 'Thank you for registering to our Gym'
            message = ' Hello '
            email_from = 'nishchithap689@gmail.com'
            recipient_list = [j.email]
            send_mail(subject, message, email_from, recipient_list)
    return HttpResponse('Mail sent successfully')


EMAIL_HOST = 'smtp.gmail.com'
EMAIL_USE_TLS = True
EMAIL_PORT = 587
EMAIL_HOST_USER = 'nishchithap689@gmail.com'
EMAIL_HOST_PASSWORD = '9483749579'
from django.conf import settings


def mobile(request):
    client = TwilioRestClient(account_sid, auth_token)
    message = client.messages.create(
        body="Jenny please?! I love you <3",
        to="+918197349121",
        from_="+919483749579",
        media_url="http://www.example.com/hearts.png")
    print('sent')


def enquiry12(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        plans = request.POST['plans']
        user = enquiry1.objects.create(name=name, email=email, phone=phone, plans=plans)
        user.save()
        return HttpResponse('Registered successfully')
    return render(request, 'details.html')


def fil(request):
    if request.method == 'POST':
        date_min = request.POST['dat_min']
        date_max = request.POST['dat_max']
        enq = enquiry1.objects.filter(date__range=(date_min, date_max))
        if enq:
            return render(request, 'enq.html', {'itemt': enq})

        else:
            return HttpResponse("No data to show")

    return render(request, 'enq.html')


def itemhome(request):
    items = itemlist.objects.all()
    return render(request, 'itemhome.html', {'items': items})


def add(request):
    if request.method == 'POST':
        iname = request.POST['iname']
        price = request.POST['price']
        jan = request.POST['jan']
        feb = request.POST['feb']
        march = request.POST['march']
        april = request.POST['april']
        may = request.POST['may']
        june = request.POST['june']
        july = request.POST['july']
        aug = request.POST['aug']
        sept = request.POST['sept']
        oct = request.POST['oct']
        nov = request.POST['nov']
        dec = request.POST['dec']

        il = itemlist.objects.create(name=iname, price=price, jan=jan, feb=feb, march=march, april=april, may=may,
                                     june=june, july=july, aug=aug, sept=sept, oct=oct, nov=nov, dec=dec)
        il.save();
        print('Item inserted')
        return HttpResponseRedirect("/itemhome")
    else:
        return render(request, 'itemhome.html')


def filter(request):
    if request.method == 'POST':
        iname = request.POST['iname']
        if iname:
            i = itemlist.objects.filter(Q(name__icontains=iname))

            if i:
                return render(request, 'filter.html', {'itemt': i})

        else:
            return HttpResponseRedirect("filter")

    return render(request, 'filter.html')


def edit(request, id):
    items = itemlist.objects.get(pk=id)
    context = {
        'items': items
    }
    return render(request, 'edit.html', context)


def update(request, id):
    items = itemlist.objects.get(pk=id)
    items.name = request.GET['iname']
    items.jan = request.GET['jan']
    items.feb = request.GET['feb']
    items.march = request.GET['march']
    items.april = request.GET['april']
    items.may = request.GET['may']
    items.june = request.GET['june']
    items.july = request.GET['july']
    items.aug = request.GET['aug']
    items.sept = request.GET['sept']
    items.oct = request.GET['oct']
    items.nov = request.GET['nov']
    items.dec = request.GET['dec']

    items.save()
    return redirect('/itemhome')


class Pdf(View):

    def get(self, request):
        sales = itemlist.objects.all()
        params = {
            'items': sales,
            'request': request
        }
        return Render.render('invoice.html', params)


def Home(request):
    MERCHANT_KEY = " YCEIpmvs"
    key = "YCEIpmvs"
    SALT = "Ek7BjVCCAY"
    PAYU_BASE_URL = "https://sandboxsecure.payu.in/_payment"
    action = ''
    posted = {'amount': '10',
              'firstname': 'renjith',
              'email': 'sraj@gmail.com',
              'phone': '9746272610', 'productinfo': 'test',
              'surl': 'http://127.0.0.1:8000/payment/Success/',
              'furl': 'http://127.0.0.1:8000/payment/Failure/',
              'lastname': 'test', 'address1': 'test',
              'address2': 'test', 'city': 'test',
              'state': 'test', 'country': 'test',
              'zipcode': 'tes', 'udf1': '',
              'udf2': '', 'udf3': '', 'udf4': '', 'udf5': ''
              }
    # Merchant Key and Salt provided y the PayU.
    for i in request.POST:
        posted[i] = request.POST[i]
    hash_object = hashlib.sha256(b'randint(0,20)')
    txnid = hash_object.hexdigest()[0:20]
    hashh = ''
    posted['txnid'] = txnid
    hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10"
    posted['key'] = key
    hash_string = ''
    hashVarsSeq = hashSequence.split('|')
    for i in hashVarsSeq:
        try:
            hash_string += str(posted[i])
        except Exception:
            hash_string += ''
        hash_string += '|'
    hash_string += SALT
    hashh = hashlib.sha512(hash_string.encode('utf-8')).hexdigest().lower()
    action = PAYU_BASE_URL
    mycontext = {"head": "PayU Money", "MERCHANT_KEY": MERCHANT_KEY, "posted": posted, "hashh": hashh,
                 "hash_string": hash_string, "txnid": txnid, "action": action}

    if (posted.get("key") != None and posted.get("txnid") != None and posted.get("productinfo") != None and posted.get(
            "firstname") is not None and posted.get("email") != None):
        return render(request, 'current_datetime.html', context=mycontext)
    else:
        return render_to_response('current_datetime.html', RequestContext(request, {"posted": posted, "hashh": hashh,
                                                                                    "MERCHANT_KEY": MERCHANT_KEY,
                                                                                    "txnid": txnid,
                                                                                    "hash_string": hash_string,
                                                                                    "action": action}))


@csrf_protect
@csrf_exempt
def success(request):
    c = {}
    c.update(csrf(request))
    status = request.POST.get("status")
    firstname = request.POST.get("firstname")
    amount = request.POST.get("amount")
    txnid = request.POST.get("txnid")
    posted_hash = request.POST.get("hash")
    key = request.POST.get("key")
    productinfo = request.POST.get("productinfo")
    email = request.POST.get("email")
    salt = "GQs7yium"
    try:
        additionalCharges = request.POST["additionalCharges"]
        retHashSeq = additionalCharges + '|' + salt + '|' + status + '|||||||||||' + email + '|' + firstname + '|' + productinfo + '|' + amount + '|' + txnid + '|' + key
    except Exception:
        retHashSeq = salt + '|' + status + '|||||||||||' + email + '|' + firstname + '|' + productinfo + '|' + amount + '|' + txnid + '|' + key
    hashh = hashlib.sha512(retHashSeq.encode('utf-8')).hexdigest().lower()
    if (hashh != posted_hash):
        print("Invalid Transaction. Please try again")
    else:
        print("Thank You. Your order status is ", status)
        print("Your Transaction ID for this transaction is ", txnid)
        print("We have received a payment of Rs. ", amount, ". Your order will soon be shipped.")
    context = {"txnid": txnid, "status": status, "amount": amount}
    return render_to_response('sucess.html', RequestContext(request, context))


@csrf_protect
@csrf_exempt
def failure(request):
    c = {}
    c.update(csrf(request))
    status = request.POST.get("status")
    firstname = request.POST.get("firstname")
    amount = request.POST.get("amount")
    txnid = request.POST.get("txnid")
    posted_hash = request.POST.get("hash")
    key = request.POST.get("key")
    productinfo = request.POST.get("productinfo")
    email = request.POST.get("email")
    salt = "q2plxvdank"
    try:
        additionalCharges = request.POST["additionalCharges"]
        retHashSeq = additionalCharges + '|' + salt + '|' + status + '|||||||||||' + email + '|' + firstname + '|' + productinfo + '|' + amount + '|' + txnid + '|' + key
    except Exception:
        retHashSeq = salt + '|' + status + '|||||||||||' + email + '|' + firstname + '|' + productinfo + '|' + amount + '|' + txnid + '|' + key
    hashh = hashlib.sha512(retHashSeq.encode('utf-8')).hexdigest().lower()
    if (hashh != posted_hash):
        print("Invalid Transaction. Please try again")
    else:
        print("Thank You. Your order status is ", status)
        print("Your Transaction ID for this transaction is ", txnid)
        print("We have received a payment of Rs. ", amount, ". Your order will soon be shipped.")
    return render_to_response("Failure.html", RequestContext(request, c))


def home1(request):
    first_graph = "my First django graph"
    return HttpResponse(first_graph)


def sales(request):
    price = \
        DataPool(
            series=
            [{'options': {
                'source': SalesReport.objects.all()},
                'terms': [{'month': 'month',
                           ' sales': 'sales',
                           'item': 'item',
                           'actual_price': 'actual_price'
                           }]

            }
            ])

    def monthname(month_num):
        names = {1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jue', 7: 'Jul', 8: 'Aug', 9: 'Sep', 10: 'Oct',
                 11: 'Nov', 12: 'Dec'}
        return names[month_num]

    def profit(sales, actual_price):
        profit = (sales - actual_price)
        return profit

    def loss(sales, actual_price):
        loss = (actual_price - sales)
        return loss

    cht = Chart(
        datasource=sales,
        series_options=
        [{'options': {
            'type': 'line',
            'stacking': False},
            'terms': {
                'month': [
                    'sales',
                     'item',
                     'actual_amount']
            }}],
        chart_options=
        {'title': {
            'text': 'sales Amounts over Months'},
            'xAxis': {
                'title': {'text': 'Sales Total'}},
            'yAxis': {
                'title': {'text': 'Month Number'}}},
        x_sortf_mapf_mts=(None, monthname, profit, loss, False))
    cht2 = Chart(
        datasource=sales,
        series_options=
        [{'options': {
            'type': 'pie',
            'stacking': False},
            'terms': {
                'month': [
                    'sales',
                     'item',
                     'actual_amount']

            }}],
        chart_options=
        {'title': {
            'text': 'sales Amounts Over Months - pie Chart'},
            'xAxis': {
                'title': {'text': 'Sales Total'}},
            'yAxis': {
                'title': {'text': 'Month Number'}}},
        x_sortf_mapf_mts=(None, monthname, profit, loss, False))

    return render(request, 'sales.html',
                  {'chart_list': [cht, cht2]})
