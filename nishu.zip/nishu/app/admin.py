from django.contrib import admin
from .models import promotion, enquiry1, mail1
# Register your models here.
from .models import itemlist
from .models import SalesReport

admin.site.register(SalesReport)
admin.site.register(promotion)


admin.site.register(itemlist)
admin.site.register(enquiry1)
admin.site.register(mail1)
