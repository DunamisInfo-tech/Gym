import smtplib
from datetime import timedelta, datetime, timezone

from django.core.mail import send_mail
from django.db import models
from django.utils import timezone
# Create your models here.
from django.http import HttpResponse
from werkzeug.utils import cached_property


class promotion(models.Model):
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=40)
    phone = models.IntegerField()
    start_date = models.DateField(null=True)
    duration = models.CharField(max_length=10)
    end_date = models.DateField(null=True)


class itemlist(models.Model):
    name = models.CharField(max_length=30)
    price = models.FloatField(default=0)
    jan = models.IntegerField(default=0)
    feb = models.IntegerField(default=0)
    march = models.IntegerField(default=0)
    april = models.IntegerField(default=0)
    may = models.IntegerField(default=0)
    june = models.IntegerField(default=0)
    july = models.IntegerField(default=0)
    aug = models.IntegerField(default=0)
    sept = models.IntegerField(default=0)
    oct = models.IntegerField(default=0)
    nov = models.IntegerField(default=0)
    dec = models.IntegerField(default=0)


class enquiry1(models.Model):
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=40)
    phone = models.IntegerField()
    date = models.DateField(default=timezone.now)
    plans = models.CharField(max_length=40)


class mail1(models.Model):
    email = models.EmailField()
    password = models.CharField(max_length=30)


class SalesReport(models.Model):
    month = models.IntegerField()
    sales = models.FloatField()
    item = models.CharField(max_length=25)
    actual_price = models.FloatField()
