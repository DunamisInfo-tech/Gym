from django.test import TestCase

# Create your tests here.
import sqlite3

conn = sqlite3.connect('App.db')
c = conn.cursor()

# Insert a row of data
c.execute("INSERT INTO  user VALUES ('nishu','nishchithapn9@gmail.com','456','2006-01-05','8','2006-01-05')")

# Save (commit) the changes
conn.commit()

# We can also close the connection if we are done with it.
# Just be sure any changes have been committed or they will be lost.
conn.close()
