"""nishu URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from app import views, models
from app.views import Pdf

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index', views.index, name="index"),
    path('index1', views.index1, name="index1"),

    path('index2', views.index2, name="index2"),
    path('home', views.home, name="home"),

    path('promotion', views.Promotion),
    path('mobile', views.mobile),
    path('enquiry1', views.enquiry12, name="enquiry12"),

    path("itemhome", views.itemhome, name="itemhome"),
    path("get", views.index1, name="home"),
    path("add", views.add, name="add"),
    path("filter", views.filter, name="filter"),
    path("edit/<id>/", views.edit, name="edit"),
    path("update/<id>/", views.update, name="update"),
    path('fil', views.fil, name="fil"),
    path('second', views.second, name="second"),
    path('basic', views.basic, name="basic"),
    path('pre', views.pre, name="pre"),
    path('business', views.business, name="business"),
    path('email', views.email, name="email"),
    path('email1', views.email1, name="email1"),
    path('click', views.click, name="click"),
    path('Payment', views.Home),
    path('Success', views.success),
    path('Failure', views.failure),
    path('render', Pdf.as_view()),
    path('ind', views.ind),
    path('enq', views.enq),

path('pagelogin', views.pagelogin),
path('pageregister', views.pageregister),
    path('home1', views.home1, name='home1'),
    path('sales', views.sales, name='sales'),


]
