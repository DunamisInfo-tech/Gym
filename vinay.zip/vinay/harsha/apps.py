from django.apps import AppConfig


class HarshaConfig(AppConfig):
    name = 'harsha'
